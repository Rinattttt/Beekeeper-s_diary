﻿using Beekeeper_s_diary;
using System;
using System.Windows.Forms;

public partial class MainForm : Form
{
    public MainForm()
    {
        InitializeComponent();
    }

    private void btnFamilies_Click(object sender, EventArgs e)
    {
        FamiliesForm familiesForm = new FamiliesForm();
        familiesForm.ShowDialog();
    }

    private void btnInspections_Click(object sender, EventArgs e)
    {
        HiveInspectionForm inspectionForm = new HiveInspectionForm();
        inspectionForm.ShowDialog();
    }

    private void btnEvents_Click(object sender, EventArgs e)
    {
        EventsForm eventsForm = new EventsForm();
        eventsForm.ShowDialog();
    }

    private void btnHoney_Click(object sender, EventArgs e)
    {
        HoneyHarvestForm honeyForm = new HoneyHarvestForm();
        honeyForm.ShowDialog();
    }

    private void btnSales_Click(object sender, EventArgs e)
    {
        SalesForm salesForm = new SalesForm();
        salesForm.ShowDialog();
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
        Application.Exit();
    }
    private void btnViewData_Click(object sender, EventArgs e)
    {
        DataViewForm dataViewForm = new DataViewForm();
        dataViewForm.ShowDialog();
    }
}