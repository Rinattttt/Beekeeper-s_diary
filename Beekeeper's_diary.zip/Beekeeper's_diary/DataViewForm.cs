﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace Beekeeper_s_diary
{
    public partial class DataViewForm : Form
    {
        public DataViewForm()
        {
            InitializeComponent();
            LoadAllData();
        }

        private void LoadAllData()
        {
            LoadFamilies();
            LoadInspections();
            LoadEvents();
            LoadHoneyHarvest();
            LoadSales();
        }

        private void LoadFamilies()
        {
            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = "SELECT Id, Name, Location, CreatedDate FROM BeeFamilies";
                    SQLiteDataAdapter adapter = new SQLiteDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridFamilies.DataSource = dt;

                    // Настройка заголовков
                    dataGridFamilies.Columns["Id"].Visible = false;
                    dataGridFamilies.Columns["Name"].HeaderText = "Название";
                    dataGridFamilies.Columns["Location"].HeaderText = "Расположение";
                    dataGridFamilies.Columns["CreatedDate"].HeaderText = "Дата создания";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки семей: {ex.Message}");
            }
        }

        private void LoadInspections()
        {
            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = @"SELECT 
                    hi.Id, 
                    f.Name AS Семья, 
                    hi.InspectionDate AS [Дата осмотра], 
                    hi.HealthStatus AS [Состояние здоровья], 
                    hi.Notes AS Заметки 
                FROM HiveInspections hi
                JOIN BeeFamilies f ON hi.FamilyId = f.Id";

                    SQLiteDataAdapter adapter = new SQLiteDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridInspections.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки осмотров: {ex.Message}");
            }
        }

        private void LoadEvents()
        {
            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = @"SELECT 
                    e.Id, 
                    f.Name AS Семья, 
                    CASE e.EventType
                        WHEN 'Migration' THEN 'Перегон'
                        WHEN 'Prevention' THEN 'Профилактика'
                        WHEN 'HoneyCollection' THEN 'Сбор меда'
                        WHEN 'Swarming' THEN 'Роение'
                        WHEN 'Magazines' THEN 'Магазины'
                        ELSE e.EventType
                    END AS [Тип события],
                    e.StartDate AS [Дата начала],
                    e.EndDate AS [Дата окончания],
                    e.Description AS Описание
                FROM Events e
                LEFT JOIN BeeFamilies f ON e.FamilyId = f.Id";

                    SQLiteDataAdapter adapter = new SQLiteDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridEvents.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки событий: {ex.Message}");
            }
        }

        private void LoadHoneyHarvest()
        {
            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = @"SELECT 
                    hh.Id,
                    CASE 
                        WHEN hh.FamilyId IS NULL THEN 'Общий сбор'
                        ELSE f.Name 
                    END AS Семья,
                    hh.HarvestDate AS [Дата сбора],
                    hh.Amount AS [Количество (кг)]
                FROM HoneyHarvest hh
                LEFT JOIN BeeFamilies f ON hh.FamilyId = f.Id";

                    SQLiteDataAdapter adapter = new SQLiteDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridHoney.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки учета меда: {ex.Message}");
            }
        }

        private void LoadSales()
        {
            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = @"SELECT 
                    Id,
                    ClientName AS Клиент,
                    SaleDate AS [Дата продажи],
                    Amount AS [Количество (кг)],
                    Profit AS Прибыль
                FROM Sales";

                    SQLiteDataAdapter adapter = new SQLiteDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridSales.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки продаж: {ex.Message}");
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadAllData();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
