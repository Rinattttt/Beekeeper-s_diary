﻿using Beekeeper_s_diary;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Windows.Forms;

namespace Beekeeper_s_diary
{
    public partial class HiveInspectionForm : Form
    {
        private List<KeyValuePair<int, string>> families = new List<KeyValuePair<int, string>>();

        public HiveInspectionForm()
        {
            InitializeComponent();
            LoadFamilies();
            dtpInspectionDate.Value = DateTime.Today;
        }

        private void LoadFamilies()
        {
            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = "SELECT Id, Name FROM BeeFamilies";

                    using (var cmd = new SQLiteCommand(sql, conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            families.Add(new KeyValuePair<int, string>(
                                reader.GetInt32(0),
                                reader.GetString(1)
                            ));
                        }
                    }
                }

                comboFamilies.DisplayMember = "Value";
                comboFamilies.ValueMember = "Key";
                comboFamilies.DataSource = families;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки семей: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (comboFamilies.SelectedItem == null)
            {
                MessageBox.Show("Выберите семью", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var selectedFamily = (KeyValuePair<int, string>)comboFamilies.SelectedItem;

            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = @"INSERT INTO HiveInspections 
                             (FamilyId, InspectionDate, HealthStatus, Notes) 
                             VALUES (@familyId, @date, @health, @notes)";

                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@familyId", selectedFamily.Key);
                        cmd.Parameters.AddWithValue("@date", dtpInspectionDate.Value.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@health", txtHealthStatus.Text);
                        cmd.Parameters.AddWithValue("@notes", txtNotes.Text);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Данные осмотра сохранены", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearForm()
        {
            txtHealthStatus.Clear();
            txtNotes.Clear();
            dtpInspectionDate.Value = DateTime.Today;
            if (comboFamilies.Items.Count > 0) comboFamilies.SelectedIndex = 0;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtHealthStatus_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
