﻿using System.Windows.Forms;
partial class MainForm
{
    private Button btnFamilies;
    private Button btnInspections;
    private Button btnEvents;
    private Button btnHoney;
    private Button btnSales;
    private Button btnExit;
    private Button btnViewData;

    private void InitializeComponent()
    {
        this.btnFamilies = new Button();
        this.btnInspections = new Button();
        this.btnEvents = new Button();
        this.btnHoney = new Button();
        this.btnSales = new Button();
        this.btnExit = new Button();
        this.btnViewData = new Button();

        // Buttons
        int buttonWidth = 200;
        int buttonHeight = 40;
        int startY = 20;
        int spacing = 10;

        Button[] buttons = { btnFamilies, btnInspections, btnEvents, btnHoney, btnSales, btnExit, btnViewData };
        string[] buttonTexts = {
            "Пчелиные семьи", "Осмотры ульев", "Расписание событий",
            "Учет сбора меда", "Учет продаж", "Выход", "Просмотр данных"
        };

        for (int i = 0; i < buttons.Length; i++)
        {
            buttons[i].Text = buttonTexts[i];
            buttons[i].Size = new System.Drawing.Size(buttonWidth, buttonHeight);
            buttons[i].Location = new System.Drawing.Point(50, startY + i * (buttonHeight + spacing));
            buttons[i].BackColor = System.Drawing.Color.Orange;
        }

        // Event Handlers
        this.btnFamilies.Click += new System.EventHandler(this.btnFamilies_Click);
        this.btnInspections.Click += new System.EventHandler(this.btnInspections_Click);
        this.btnEvents.Click += new System.EventHandler(this.btnEvents_Click);
        this.btnHoney.Click += new System.EventHandler(this.btnHoney_Click);
        this.btnSales.Click += new System.EventHandler(this.btnSales_Click);
        this.btnViewData.Click += new System.EventHandler(this.btnViewData_Click);
        this.btnExit.Click += new System.EventHandler(this.btnExit_Click);

        // Form
        this.ClientSize = new System.Drawing.Size(300, 400);
        this.BackgroundImage = global::Beekeeper_s_diary.Properties.Resources.Снимок_экрана_2025_05_29_144415;
        this.Text = "Дневник пчеловода";
        this.Controls.AddRange(buttons);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
    }
}