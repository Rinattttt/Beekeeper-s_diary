﻿using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;

namespace Beekeeper_s_diary
{
    public partial class FamiliesForm : Form
    {
        public FamiliesForm()
        {
            InitializeComponent();
            LoadFamilies();
        }

        private void LoadFamilies()
        {
            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = "SELECT Id, Name, Location, CreatedDate FROM BeeFamilies";

                    using (var adapter = new SQLiteDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridViewFamilies.DataSource = dt;

                        // Настройка заголовков
                        if (dataGridViewFamilies.Columns.Count > 0)
                        {
                            dataGridViewFamilies.Columns["Id"].Visible = false;
                            dataGridViewFamilies.Columns["Name"].HeaderText = "Название";
                            dataGridViewFamilies.Columns["Location"].HeaderText = "Расположение";
                            dataGridViewFamilies.Columns["CreatedDate"].HeaderText = "Дата создания";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            FamilyEditForm editForm = new FamilyEditForm();
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                LoadFamilies();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridViewFamilies.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите семью для редактирования", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int familyId = Convert.ToInt32(dataGridViewFamilies.SelectedRows[0].Cells["Id"].Value);
            FamilyEditForm editForm = new FamilyEditForm(familyId);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                LoadFamilies();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewFamilies.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите семью для удаления", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Вы уверены, что хотите удалить выбранную семью?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int familyId = Convert.ToInt32(dataGridViewFamilies.SelectedRows[0].Cells["Id"].Value);

                try
                {
                    using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                    {
                        conn.Open();
                        string sql = "DELETE FROM BeeFamilies WHERE Id = @id";

                        using (var cmd = new SQLiteCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@id", familyId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    LoadFamilies();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
