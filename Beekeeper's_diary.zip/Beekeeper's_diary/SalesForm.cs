﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace Beekeeper_s_diary
{
    public partial class SalesForm : Form
    {
        public SalesForm()
        {
            InitializeComponent();
            dtpSaleDate.Value = DateTime.Today;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtClient.Text))
            {
                MessageBox.Show("Введите имя клиента", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (numAmount.Value <= 0)
            {
                MessageBox.Show("Введите количество меда", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (numProfit.Value <= 0)
            {
                MessageBox.Show("Введите прибыль", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = @"INSERT INTO Sales 
                     (ClientName, SaleDate, Amount, Profit) 
                     VALUES (@client, @date, @amount, @profit)";

                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@client", txtClient.Text);
                        cmd.Parameters.AddWithValue("@date", dtpSaleDate.Value.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@amount", numAmount.Value);
                        cmd.Parameters.AddWithValue("@profit", numProfit.Value);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Данные продажи сохранены", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearForm()
        {
            txtClient.Clear();
            numAmount.Value = 0;
            numProfit.Value = 0;
            dtpSaleDate.Value = DateTime.Today;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
