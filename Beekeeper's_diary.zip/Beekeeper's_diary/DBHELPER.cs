﻿using System.Windows.Forms;
using System.Configuration;
using System.Data.SQLite;
using System.IO;
using System;

namespace Beekeeper_s_diary
{
    public static class DatabaseHelper
    {
        public static string ConnectionString =>
            ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        public static void InitializeDatabase()
        {
            if (!File.Exists("BeekeepingDB.sqlite"))
            {
                SQLiteConnection.CreateFile("BeekeepingDB.sqlite");

                using (var conn = new SQLiteConnection(ConnectionString))
                {
                    conn.Open();

                    ExecuteNonQuery(conn, @"
                    CREATE TABLE Users (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Login TEXT UNIQUE NOT NULL,
                        PasswordHash TEXT UNIQUE NOT NULL
                    )");

                    ExecuteNonQuery(conn, @"
                    CREATE TABLE BeeFamilies (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Name TEXT NOT NULL,
                        Location TEXT,
                        CreatedDate TEXT NOT NULL
                    )");

                    ExecuteNonQuery(conn, @"
                    CREATE TABLE HiveInspections (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        FamilyId INTEGER NOT NULL,
                        InspectionDate TEXT NOT NULL,
                        HealthStatus TEXT,
                        Notes TEXT,
                        FOREIGN KEY(FamilyId) REFERENCES BeeFamilies(Id) ON DELETE CASCADE
                    )");

                    ExecuteNonQuery(conn, @"
                    CREATE TABLE Events (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        FamilyId INTEGER,
                        EventType TEXT NOT NULL,
                        StartDate TEXT NOT NULL,
                        EndDate TEXT,
                        Description TEXT,
                        FOREIGN KEY(FamilyId) REFERENCES BeeFamilies(Id) ON DELETE CASCADE
                    )");

                    ExecuteNonQuery(conn, @"
                    CREATE TABLE HoneyHarvest (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        FamilyId INTEGER,
                        HarvestDate TEXT NOT NULL,
                        Amount REAL NOT NULL,
                        FOREIGN KEY(FamilyId) REFERENCES BeeFamilies(Id) ON DELETE CASCADE
                    )");

                    ExecuteNonQuery(conn, @"
                    CREATE TABLE Sales (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        ClientName TEXT NOT NULL,
                        SaleDate TEXT NOT NULL,
                        Amount REAL NOT NULL,
                        Profit REAL NOT NULL
                    )");
                }

                string dbPath = "BeekeepingDB.sqlite";

                if (!File.Exists(dbPath))
                {
                    try
                    {
                        SQLiteConnection.CreateFile(dbPath);
                        // ... остальной код создания таблиц
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка создания БД: {ex.Message}");
                    }
                }
            }
        }
    
        private static void ExecuteNonQuery(SQLiteConnection conn, string sql)
        {
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        private static void RegisterUser(string login, string password)
        {
            string AbsolutePathToDBFile = "C:\\Users\\Alena\\source\\repos\\Beekeeper's_diary\\Beekeeper's_diary\\bin\\Debug\\Db beekeeper's diary.db";
            using (var conn = new SQLiteConnection($"Data Source={AbsolutePathToDBFile}"))
            {
                conn.Open();
                var hashedPassword = HashPassword(password);
                var sql = "INSERT INTO Users (Login, PasswordHash) VALUES (@login, @hash)";

                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login);
                    cmd.Parameters.AddWithValue("@hash", hashedPassword);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static string HashPassword(string password)
        {
            using (var sha256 = System.Security.Cryptography.SHA256.Create())
            {
                var bytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }
    }
}
