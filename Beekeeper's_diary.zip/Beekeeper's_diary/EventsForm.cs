﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Windows.Forms;

namespace Beekeeper_s_diary
{
    public partial class EventsForm : Form
    {
        private List<KeyValuePair<int, string>> families = new List<KeyValuePair<int, string>>();
        private Dictionary<string, string> eventTypes = new Dictionary<string, string>
    {
        {"Migration", "Перегон семей"},
        {"Prevention", "Профилактика"},
        {"HoneyCollection", "Сбор меда"},
        {"Swarming", "Период роения"},
        {"Magazines", "Расстановка магазинов"}
    };

        public EventsForm()
        {
            InitializeComponent();
            LoadFamilies();
            LoadEventTypes();
            dtpStartDate.Value = DateTime.Today;
            dtpEndDate.Value = DateTime.Today;
        }

        private void LoadFamilies()
        {
            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = "SELECT Id, Name FROM BeeFamilies";

                    using (var cmd = new SQLiteCommand(sql, conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            families.Add(new KeyValuePair<int, string>(
                                reader.GetInt32(0),
                                reader.GetString(1)
                            ));
                        }
                    }
                }

                comboFamilies.DisplayMember = "Value";
                comboFamilies.ValueMember = "Key";
                comboFamilies.DataSource = families;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки семей: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadEventTypes()
        {
            comboEventType.DisplayMember = "Value";
            comboEventType.ValueMember = "Key";
            comboEventType.DataSource = new BindingSource(eventTypes, null);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (comboEventType.SelectedItem == null)
            {
                MessageBox.Show("Выберите тип события", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var eventType = (KeyValuePair<string, string>)comboEventType.SelectedItem;
            var family = (KeyValuePair<int, string>)comboFamilies.SelectedItem;

            if (dtpStartDate.Value > dtpEndDate.Value)
            {
                MessageBox.Show("Дата окончания не может быть раньше даты начала", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = @"INSERT INTO Events 
                             (FamilyId, EventType, StartDate, EndDate, Description) 
                             VALUES (@familyId, @type, @start, @end, @desc)";

                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@familyId", family.Key);
                        cmd.Parameters.AddWithValue("@type", eventType.Key);
                        cmd.Parameters.AddWithValue("@start", dtpStartDate.Value.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@end", dtpEndDate.Value.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@desc", txtDescription.Text);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Событие сохранено", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearForm()
        {
            txtDescription.Clear();
            dtpStartDate.Value = DateTime.Today;
            dtpEndDate.Value = DateTime.Today;
            if (comboEventType.Items.Count > 0) comboEventType.SelectedIndex = 0;
            if (comboFamilies.Items.Count > 0) comboFamilies.SelectedIndex = 0;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
