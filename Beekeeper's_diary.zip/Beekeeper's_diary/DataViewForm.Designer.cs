﻿using System.Drawing;
using System.Windows.Forms;

namespace Beekeeper_s_diary
{
    partial class DataViewForm
    {
        private TabControl tabControl;
        private TabPage tabFamilies;
        private TabPage tabInspections;
        private TabPage tabEvents;
        private TabPage tabHoney;
        private TabPage tabSales;
        private DataGridView dataGridFamilies;
        private DataGridView dataGridInspections;
        private DataGridView dataGridEvents;
        private DataGridView dataGridHoney;
        private DataGridView dataGridSales;
        private Button btnRefresh;
        private Button btnClose;

        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabFamilies = new System.Windows.Forms.TabPage();
            this.dataGridFamilies = new System.Windows.Forms.DataGridView();
            this.tabInspections = new System.Windows.Forms.TabPage();
            this.dataGridInspections = new System.Windows.Forms.DataGridView();
            this.tabEvents = new System.Windows.Forms.TabPage();
            this.dataGridEvents = new System.Windows.Forms.DataGridView();
            this.tabHoney = new System.Windows.Forms.TabPage();
            this.dataGridHoney = new System.Windows.Forms.DataGridView();
            this.tabSales = new System.Windows.Forms.TabPage();
            this.dataGridSales = new System.Windows.Forms.DataGridView();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tabControl.SuspendLayout();
            this.tabFamilies.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridFamilies)).BeginInit();
            this.tabInspections.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridInspections)).BeginInit();
            this.tabEvents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridEvents)).BeginInit();
            this.tabHoney.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridHoney)).BeginInit();
            this.tabSales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSales)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabFamilies);
            this.tabControl.Controls.Add(this.tabInspections);
            this.tabControl.Controls.Add(this.tabEvents);
            this.tabControl.Controls.Add(this.tabHoney);
            this.tabControl.Controls.Add(this.tabSales);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(600, 400);
            this.tabControl.TabIndex = 0;
            // 
            // tabFamilies
            // 
            this.tabFamilies.Controls.Add(this.dataGridFamilies);
            this.tabFamilies.Location = new System.Drawing.Point(4, 25);
            this.tabFamilies.Name = "tabFamilies";
            this.tabFamilies.Size = new System.Drawing.Size(592, 371);
            this.tabFamilies.TabIndex = 0;
            this.tabFamilies.Text = "Пчелиные семьи";
            // 
            // dataGridFamilies
            // 
            this.dataGridFamilies.BackgroundColor = System.Drawing.Color.Orange;
            this.dataGridFamilies.ColumnHeadersHeight = 29;
            this.dataGridFamilies.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridFamilies.Location = new System.Drawing.Point(0, 0);
            this.dataGridFamilies.Name = "dataGridFamilies";
            this.dataGridFamilies.RowHeadersWidth = 51;
            this.dataGridFamilies.Size = new System.Drawing.Size(592, 371);
            this.dataGridFamilies.TabIndex = 0;
            // 
            // tabInspections
            // 
            this.tabInspections.Controls.Add(this.dataGridInspections);
            this.tabInspections.Location = new System.Drawing.Point(4, 25);
            this.tabInspections.Name = "tabInspections";
            this.tabInspections.Size = new System.Drawing.Size(592, 371);
            this.tabInspections.TabIndex = 1;
            this.tabInspections.Text = "Осмотры ульев";
            // 
            // dataGridInspections
            // 
            this.dataGridInspections.BackgroundColor = System.Drawing.Color.Orange;
            this.dataGridInspections.ColumnHeadersHeight = 29;
            this.dataGridInspections.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridInspections.Location = new System.Drawing.Point(0, 0);
            this.dataGridInspections.Name = "dataGridInspections";
            this.dataGridInspections.RowHeadersWidth = 51;
            this.dataGridInspections.Size = new System.Drawing.Size(592, 371);
            this.dataGridInspections.TabIndex = 0;
            // 
            // tabEvents
            // 
            this.tabEvents.Controls.Add(this.dataGridEvents);
            this.tabEvents.Location = new System.Drawing.Point(4, 25);
            this.tabEvents.Name = "tabEvents";
            this.tabEvents.Size = new System.Drawing.Size(592, 371);
            this.tabEvents.TabIndex = 2;
            this.tabEvents.Text = "События";
            // 
            // dataGridEvents
            // 
            this.dataGridEvents.BackgroundColor = System.Drawing.Color.Orange;
            this.dataGridEvents.ColumnHeadersHeight = 29;
            this.dataGridEvents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridEvents.Location = new System.Drawing.Point(0, 0);
            this.dataGridEvents.Name = "dataGridEvents";
            this.dataGridEvents.RowHeadersWidth = 51;
            this.dataGridEvents.Size = new System.Drawing.Size(592, 371);
            this.dataGridEvents.TabIndex = 0;
            // 
            // tabHoney
            // 
            this.tabHoney.Controls.Add(this.dataGridHoney);
            this.tabHoney.Location = new System.Drawing.Point(4, 25);
            this.tabHoney.Name = "tabHoney";
            this.tabHoney.Size = new System.Drawing.Size(592, 371);
            this.tabHoney.TabIndex = 3;
            this.tabHoney.Text = "Учет меда";
            // 
            // dataGridHoney
            // 
            this.dataGridHoney.BackgroundColor = System.Drawing.Color.Orange;
            this.dataGridHoney.ColumnHeadersHeight = 29;
            this.dataGridHoney.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridHoney.Location = new System.Drawing.Point(0, 0);
            this.dataGridHoney.Name = "dataGridHoney";
            this.dataGridHoney.RowHeadersWidth = 51;
            this.dataGridHoney.Size = new System.Drawing.Size(592, 371);
            this.dataGridHoney.TabIndex = 0;
            // 
            // tabSales
            // 
            this.tabSales.Controls.Add(this.dataGridSales);
            this.tabSales.Location = new System.Drawing.Point(4, 25);
            this.tabSales.Name = "tabSales";
            this.tabSales.Size = new System.Drawing.Size(592, 371);
            this.tabSales.TabIndex = 4;
            this.tabSales.Text = "Продажи";
            // 
            // dataGridSales
            // 
            this.dataGridSales.BackgroundColor = System.Drawing.Color.Orange;
            this.dataGridSales.ColumnHeadersHeight = 29;
            this.dataGridSales.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridSales.Location = new System.Drawing.Point(0, 0);
            this.dataGridSales.Name = "dataGridSales";
            this.dataGridSales.RowHeadersWidth = 51;
            this.dataGridSales.Size = new System.Drawing.Size(592, 371);
            this.dataGridSales.TabIndex = 0;
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.Orange;
            this.btnRefresh.Location = new System.Drawing.Point(175, 432);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 30);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "Обновить";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Orange;
            this.btnClose.Location = new System.Drawing.Point(325, 432);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 30);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "Закрыть";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // DataViewForm
            // 
            this.BackgroundImage = global::Beekeeper_s_diary.Properties.Resources.Снимок_экрана_2025_05_29_144415;
            this.ClientSize = new System.Drawing.Size(600, 500);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnClose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "DataViewForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Просмотр всех данных";
            this.tabControl.ResumeLayout(false);
            this.tabFamilies.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridFamilies)).EndInit();
            this.tabInspections.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridInspections)).EndInit();
            this.tabEvents.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridEvents)).EndInit();
            this.tabHoney.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridHoney)).EndInit();
            this.tabSales.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSales)).EndInit();
            this.ResumeLayout(false);

        }
    }
}