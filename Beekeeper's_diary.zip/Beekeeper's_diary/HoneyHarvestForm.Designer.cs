﻿using System.Windows.Forms;

namespace Beekeeper_s_diary
{
    partial class HoneyHarvestForm
    {
        private ComboBox comboFamilies;
        private DateTimePicker dtpHarvestDate;
        private NumericUpDown numAmount;
        private Button btnSave;
        private Button btnClose;
        private Label label1;
        private Label label2;
        private Label label3;
        private CheckBox chkTotal;

        private void InitializeComponent()
        {
            this.comboFamilies = new System.Windows.Forms.ComboBox();
            this.dtpHarvestDate = new System.Windows.Forms.DateTimePicker();
            this.numAmount = new System.Windows.Forms.NumericUpDown();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.chkTotal = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numAmount)).BeginInit();
            this.SuspendLayout();
            // 
            // comboFamilies
            // 
            this.comboFamilies.BackColor = System.Drawing.Color.Orange;
            this.comboFamilies.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboFamilies.Location = new System.Drawing.Point(150, 30);
            this.comboFamilies.Name = "comboFamilies";
            this.comboFamilies.Size = new System.Drawing.Size(200, 24);
            this.comboFamilies.TabIndex = 0;
            // 
            // dtpHarvestDate
            // 
            this.dtpHarvestDate.CalendarForeColor = System.Drawing.Color.Orange;
            this.dtpHarvestDate.CalendarMonthBackground = System.Drawing.Color.Orange;
            this.dtpHarvestDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpHarvestDate.Location = new System.Drawing.Point(150, 70);
            this.dtpHarvestDate.Name = "dtpHarvestDate";
            this.dtpHarvestDate.Size = new System.Drawing.Size(100, 22);
            this.dtpHarvestDate.TabIndex = 1;
            // 
            // numAmount
            // 
            this.numAmount.BackColor = System.Drawing.Color.Orange;
            this.numAmount.DecimalPlaces = 2;
            this.numAmount.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numAmount.Location = new System.Drawing.Point(168, 111);
            this.numAmount.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numAmount.Name = "numAmount";
            this.numAmount.Size = new System.Drawing.Size(100, 22);
            this.numAmount.TabIndex = 2;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Orange;
            this.btnSave.Location = new System.Drawing.Point(100, 190);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Orange;
            this.btnClose.Location = new System.Drawing.Point(210, 190);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 30);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "Закрыть";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Orange;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(20, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 23);
            this.label1.TabIndex = 5;
            this.label1.Text = "Семья:";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Orange;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(20, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 23);
            this.label2.TabIndex = 6;
            this.label2.Text = "Дата сбора:";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Orange;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(20, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 23);
            this.label3.TabIndex = 7;
            this.label3.Text = "Количество (кг):";
            // 
            // chkTotal
            // 
            this.chkTotal.BackColor = System.Drawing.Color.Orange;
            this.chkTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chkTotal.Location = new System.Drawing.Point(20, 150);
            this.chkTotal.Name = "chkTotal";
            this.chkTotal.Size = new System.Drawing.Size(142, 24);
            this.chkTotal.TabIndex = 8;
            this.chkTotal.Text = "Общий сбор";
            this.chkTotal.UseVisualStyleBackColor = false;
            this.chkTotal.CheckedChanged += new System.EventHandler(this.chkTotal_CheckedChanged);
            // 
            // HoneyHarvestForm
            // 
            this.BackgroundImage = global::Beekeeper_s_diary.Properties.Resources.Снимок_экрана_2025_05_29_144415;
            this.ClientSize = new System.Drawing.Size(380, 240);
            this.Controls.Add(this.comboFamilies);
            this.Controls.Add(this.dtpHarvestDate);
            this.Controls.Add(this.numAmount);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chkTotal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "HoneyHarvestForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Учет сбора меда";
            ((System.ComponentModel.ISupportInitialize)(this.numAmount)).EndInit();
            this.ResumeLayout(false);

        }
    }
}