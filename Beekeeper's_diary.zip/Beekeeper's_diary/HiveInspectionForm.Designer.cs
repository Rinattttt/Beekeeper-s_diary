﻿using System.Windows.Forms;

namespace Beekeeper_s_diary
{
    partial class HiveInspectionForm
    {
        private ComboBox comboFamilies;
        private DateTimePicker dtpInspectionDate;
        private TextBox txtHealthStatus;
        private TextBox txtNotes;
        private Button btnSave;
        private Button btnClose;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HiveInspectionForm));
            this.comboFamilies = new System.Windows.Forms.ComboBox();
            this.dtpInspectionDate = new System.Windows.Forms.DateTimePicker();
            this.txtHealthStatus = new System.Windows.Forms.TextBox();
            this.txtNotes = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboFamilies
            // 
            this.comboFamilies.BackColor = System.Drawing.Color.Orange;
            this.comboFamilies.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboFamilies.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboFamilies.Location = new System.Drawing.Point(210, 28);
            this.comboFamilies.Name = "comboFamilies";
            this.comboFamilies.Size = new System.Drawing.Size(200, 24);
            this.comboFamilies.TabIndex = 0;
            // 
            // dtpInspectionDate
            // 
            this.dtpInspectionDate.CalendarForeColor = System.Drawing.Color.Orange;
            this.dtpInspectionDate.CalendarMonthBackground = System.Drawing.Color.Orange;
            this.dtpInspectionDate.CalendarTitleBackColor = System.Drawing.SystemColors.ActiveBorder;
            this.dtpInspectionDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInspectionDate.Location = new System.Drawing.Point(210, 71);
            this.dtpInspectionDate.Name = "dtpInspectionDate";
            this.dtpInspectionDate.Size = new System.Drawing.Size(100, 22);
            this.dtpInspectionDate.TabIndex = 1;
            // 
            // txtHealthStatus
            // 
            this.txtHealthStatus.BackColor = System.Drawing.Color.Orange;
            this.txtHealthStatus.Location = new System.Drawing.Point(210, 111);
            this.txtHealthStatus.Name = "txtHealthStatus";
            this.txtHealthStatus.Size = new System.Drawing.Size(200, 22);
            this.txtHealthStatus.TabIndex = 2;
            this.txtHealthStatus.TextChanged += new System.EventHandler(this.txtHealthStatus_TextChanged);
            // 
            // txtNotes
            // 
            this.txtNotes.BackColor = System.Drawing.Color.Orange;
            this.txtNotes.Location = new System.Drawing.Point(210, 150);
            this.txtNotes.Multiline = true;
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNotes.Size = new System.Drawing.Size(200, 80);
            this.txtNotes.TabIndex = 3;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Orange;
            this.btnSave.Location = new System.Drawing.Point(82, 301);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Orange;
            this.btnClose.Location = new System.Drawing.Point(231, 301);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 30);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "Закрыть";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DarkOrange;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 23);
            this.label1.TabIndex = 6;
            this.label1.Text = "Семья:";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.DarkOrange;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 23);
            this.label2.TabIndex = 7;
            this.label2.Text = "Дата осмотра:";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.DarkOrange;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(12, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(183, 23);
            this.label3.TabIndex = 8;
            this.label3.Text = "Состояние здоровья:";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.DarkOrange;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(12, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(145, 23);
            this.label4.TabIndex = 9;
            this.label4.Text = "Заметки:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // HiveInspectionForm
            // 
            this.BackgroundImage = global::Beekeeper_s_diary.Properties.Resources.Снимок_экрана_2025_05_29_144415;
            this.ClientSize = new System.Drawing.Size(427, 343);
            this.Controls.Add(this.comboFamilies);
            this.Controls.Add(this.dtpInspectionDate);
            this.Controls.Add(this.txtHealthStatus);
            this.Controls.Add(this.txtNotes);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "HiveInspectionForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Осмотр ульев";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}