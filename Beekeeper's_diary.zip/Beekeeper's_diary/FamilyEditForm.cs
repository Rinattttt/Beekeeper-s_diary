﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace Beekeeper_s_diary
{
    public partial class FamilyEditForm : Form
    {
        private int? familyId = null;

        public FamilyEditForm()
        {
            InitializeComponent();
            dtpCreatedDate.Value = DateTime.Today;
        }

        public FamilyEditForm(int id) : this()
        {
            familyId = id;
            LoadFamilyData();
        }

        private void LoadFamilyData()
        {
            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = "SELECT Name, Location, CreatedDate FROM BeeFamilies WHERE Id = @id";

                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", familyId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtName.Text = reader["Name"].ToString();
                                txtLocation.Text = reader["Location"].ToString();
                                dtpCreatedDate.Value = DateTime.Parse(reader["CreatedDate"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название семьи", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql;

                    if (familyId == null)
                    {
                        
                        sql = @"INSERT INTO BeeFamilies (Name, Location, CreatedDate) 
                       VALUES (@name, @location, @createdDate)";
                    }
                    else
                    {
                        sql = @"UPDATE BeeFamilies 
                       SET Name = @name, Location = @location, CreatedDate = @createdDate 
                       WHERE Id = @id";
                    }

                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@name", txtName.Text);
                        cmd.Parameters.AddWithValue("@location", txtLocation.Text);
                        cmd.Parameters.AddWithValue("@createdDate", dtpCreatedDate.Value.ToString("yyyy-MM-dd"));

                        if (familyId != null)
                        {
                            cmd.Parameters.AddWithValue("@id", familyId);
                        }

                        cmd.ExecuteNonQuery();
                    }
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
