﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Windows.Forms;

namespace Beekeeper_s_diary
{
    public partial class HoneyHarvestForm : Form
    {
        private List<KeyValuePair<int, string>> families = new List<KeyValuePair<int, string>>();

        public HoneyHarvestForm()
        {
            InitializeComponent();
            LoadFamilies();
            dtpHarvestDate.Value = DateTime.Today;
        }

        private void LoadFamilies()
        {
            try
            {
                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = "SELECT Id, Name FROM BeeFamilies";

                    using (var cmd = new SQLiteCommand(sql, conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            families.Add(new KeyValuePair<int, string>(
                                reader.GetInt32(0),
                                reader.GetString(1)
                            ));
                        }
                    }
                }

                comboFamilies.DisplayMember = "Value";
                comboFamilies.ValueMember = "Key";
                comboFamilies.DataSource = families;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки семей: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void chkTotal_CheckedChanged(object sender, EventArgs e)
        {
            comboFamilies.Enabled = !chkTotal.Checked;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (numAmount.Value <= 0)
            {
                MessageBox.Show("Введите количество меда", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                int? familyId = chkTotal.Checked ? null : (int?)((KeyValuePair<int, string>)comboFamilies.SelectedItem).Key;

                using (var conn = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    conn.Open();
                    string sql = @"INSERT INTO HoneyHarvest 
                             (FamilyId, HarvestDate, Amount) 
                             VALUES (@familyId, @date, @amount)";

                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        if (familyId.HasValue)
                            cmd.Parameters.AddWithValue("@familyId", familyId.Value);
                        else
                            cmd.Parameters.AddWithValue("@familyId", DBNull.Value);

                        cmd.Parameters.AddWithValue("@date", dtpHarvestDate.Value.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@amount", numAmount.Value);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Данные сохранены", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearForm()
        {
            numAmount.Value = 0;
            dtpHarvestDate.Value = DateTime.Today;
            chkTotal.Checked = false;
            if (comboFamilies.Items.Count > 0) comboFamilies.SelectedIndex = 0;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
